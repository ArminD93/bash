#!/bin/bash

SCIEZKA="$1*"
LICZBA_PLIKOW=$(find $1 -maxdepth 1 -type f | wc -l)
LICZBA_KATALOGOW=$[$(find $1 -maxdepth 1 -type d | wc -l)-1]
LICZARCH=$(ls $ARCH -1 | wc -l)


echo "W katalogu znajduje sie: $LICZBA_KATALOGOW katalogow i $LICZBA_PLIKOW plikow."

for plik in $SCIEZKA
do
	if [ -d "$plik" ]; then
		echo "$plik (katalog)"
	else
		echo "$plik (plik)"
	fi

if [ "${plik%%i*}" = "arch" ]; then
	ARCH="${plik%%i*}"
	echo "$LICZARCH"

#else
#	ARCH="${plik%%i*}"
#	echo "problem $ARCH"

fi
done
#############
for plik in $ARCH
do
	if [ "${plik##*.}" = "tar" ]; then
		echo "to jest archiwum tar"

	elif [ "${plik##*.}" = "gz" ]; then
		echo "to jest archiwum .tar.gz"
	else
		echo "to nie jest archiwum"
	fi

done	
	
